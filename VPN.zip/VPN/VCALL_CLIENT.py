# client_video.py
import cv2, socket, threading, time, numpy as np
from aes_functions import recv_with_AES, send_with_AES

all_to_die = False

def video_receiver(ip, port, session_key):
    global all_to_die
    sock = socket.socket()
    sock.connect((ip, port + 10))
    while not all_to_die:
        try:
            data = recv_with_AES(sock, session_key)
            frame = cv2.imdecode(np.frombuffer(data, np.uint8), cv2.IMREAD_COLOR)
            if frame is None:
                continue
            cv2.imshow('Incoming', frame)
            if cv2.waitKey(1) == 27:
                all_to_die = True
        except Exception as e:
            print('[RX] Error:', e)
            all_to_die = True
    sock.close()
    cv2.destroyAllWindows()

def video_sender(ip, port, session_key):
    global all_to_die
    sock = socket.socket()
    sock.connect((ip, port))
    cap = cv2.VideoCapture(0)
    while not all_to_die:
        ret, frame = cap.read()
        if not ret:
            continue
        _, buf = cv2.imencode('.jpg', frame, [cv2.IMWRITE_JPEG_QUALITY, 80])
        try:
            send_with_AES(sock, buf.tobytes(), session_key)
        except Exception as e:
            print('[TX] Error:', e)
            all_to_die = True
        time.sleep(0.04)
    cap.release()
    sock.close()

def video_call_client(ip, port, key):
    threads = [
        threading.Thread(target=video_sender,   args=(ip, port, key)),
        threading.Thread(target=video_receiver, args=(ip, port, key))
    ]
    for t in threads: t.start()
    for t in threads: t.join()

if __name__ == '__main__':
    video_call_client('127.0.0.1', 2223, b'omer')