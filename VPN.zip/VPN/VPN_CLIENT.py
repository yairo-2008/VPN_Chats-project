__author__ = 'Omer'

import wx,datetime,threading,socket,os,rsa
from aes_functions import recv_with_AES,send_with_AES

APP_SIZE_X = 700
APP_SIZE_Y = 450
client_sock = None
key = None
user_name = None

chat_data = [ {"name": "server", "last_msg": "how are you?", "time": "----","msg":[]},
]

open_chat_windows = {}


class ChatWindow(wx.Frame):
    def __init__(self, ChatName):
        super().__init__(None, title=f"{ChatName}", size=(400, 500))
        panel = wx.Panel(self)
        self.ChatName = ChatName
        label = wx.StaticText(panel, label=f"{ChatName}",pos=(180,5))
        label.SetFont(wx.Font(14, wx.FONTFAMILY_SWISS, wx.FONTSTYLE_NORMAL, wx.FONTWEIGHT_BOLD))
        self.MessagesBox = wx.TextCtrl(panel, pos=(10, 50), size=(370, 330),
                                       style=wx.TE_MULTILINE | wx.TE_READONLY | wx.TE_RICH2)
        self.SendBtn = wx.Button(panel, label="Send", pos=(300, 400))
        self.SendBtn.Bind(wx.EVT_BUTTON, self.send_msg)
        self.TextBox = wx.TextCtrl(panel, pos=(10, 400),size=(290,-1))
        self.Centre()
        self.Show()

    def send_msg(self,event):
        global client_sock
        global key
        global user_name

        msg = self.TextBox.GetValue()
        if msg == "":
            return
        self.TextBox.SetValue("")
        self.append_message(f"You: {msg}")
        now = str(datetime.datetime.now())[:19]

        for chat in chat_data:
            if chat['name'] == self.ChatName:
                chat['msg'].append(msg)
                chat['last_msg'] = msg
                chat['time'] = now
                break
        if self.ChatName == 'server':
            send_with_AES(client_sock, f'SALL~{self.ChatName}~{msg}'.encode(), key)
            return
        send_with_AES(client_sock, f'SDSM~{msg}~{self.ChatName}~{user_name}'.encode(), key)

    def append_message(self, msg):
        self.MessagesBox.AppendText(msg + "\n")

    def load_chat_history(self):
        for chat in chat_data:
            if chat['name'] == self.ChatName:
                for msg in chat['msg']:
                    self.append_message(f'{self.ChatName}:{msg}')
                break

class ChatItem(wx.Panel):
    def __init__(self, parent, chat_info):
        super().__init__(parent)
        self.chat_info = chat_info
        self.SetMinSize((-1, 70))
        self.SetBackgroundColour(wx.Colour(255, 255, 255))

        Box_sizer = wx.BoxSizer(wx.HORIZONTAL)

        text_sizer = wx.BoxSizer(wx.VERTICAL)
        name_text = wx.StaticText(self, label=chat_info["name"])
        name_text.SetFont(wx.Font(11, wx.FONTFAMILY_SWISS, wx.FONTSTYLE_NORMAL, wx.FONTWEIGHT_BOLD))

        msg_text = wx.StaticText(self, label=chat_info["last_msg"])
        msg_text.SetForegroundColour(wx.Colour(120, 120, 120))

        text_sizer.Add(name_text, 0)
        text_sizer.Add(msg_text, 0)
        Box_sizer.Add(text_sizer, 1, wx.ALIGN_CENTER_VERTICAL)

        time_text = wx.StaticText(self, label=chat_info["time"])
        time_text.SetForegroundColour(wx.Colour(100, 100, 100))
        Box_sizer.Add(time_text, 0, wx.ALL | wx.ALIGN_TOP, 10)

        self.SetSizer(Box_sizer)

        # Bind click event to the entire panel and its children
        self.Bind(wx.EVT_LEFT_DOWN, self.on_click)
        for child in self.GetChildren():
            child.Bind(wx.EVT_LEFT_DOWN, self.on_click)

    def on_click(self, event):
        name = self.chat_info["name"]
        #for window in list(open_chat_windows.values()):
            #window.Destroy()
        #open_chat_windows.clear()
        window = ChatWindow(name)
        window.load_chat_history()
        open_chat_windows[name] = window
        window.Bind(wx.EVT_CLOSE, lambda e: open_chat_windows.pop(name, None) or window.Destroy())#כאשר מישהו סוגר חלון צאט..

class ChatList(wx.ScrolledWindow):
    def __init__(self, parent):
        global chat_data
        super().__init__(parent)
        self.SetScrollRate(0, 20)
        self.sizer = wx.BoxSizer(wx.VERTICAL)
        for chat in chat_data:
            item = ChatItem(self, chat)
            self.sizer.Add(item, 0, wx.EXPAND | wx.BOTTOM, 1)
            self.sizer.Add(wx.StaticLine(self), 0, wx.EXPAND)
        self.SetSizer(self.sizer)

    def refresh_list(self):
        print(chat_data)
        self.sizer.Clear(True)
        for chat in chat_data:
            item = ChatItem(self, chat)
            self.sizer.Add(item, 0, wx.EXPAND | wx.BOTTOM, 1)
            self.sizer.Add(wx.StaticLine(self), 0, wx.EXPAND)
        self.Layout()

    def AddChat(self, new_chat):
        global chat_data
        chat_data.append(new_chat)
        self.refresh_list()

class WxVpnChatPage(wx.Frame):
    def __init__(self):
        super().__init__(None, title="Vpn Chat", size=(400, 600))
        panel = wx.Panel(self)
        sizer = wx.BoxSizer(wx.VERTICAL)

        # for the main label
        header = wx.Panel(panel, size=(-1, 50))
        header.SetBackgroundColour(wx.Colour(7, 94, 84))
        title = wx.StaticText(header, label=f"User:{user_name} || Chats:", style=wx.ALIGN_CENTER)
        title.SetForegroundColour(wx.Colour(255, 255, 255))
        title.SetFont(wx.Font(14, wx.FONTFAMILY_SWISS, wx.FONTSTYLE_NORMAL, wx.FONTWEIGHT_BOLD))
        hs = wx.BoxSizer(wx.VERTICAL)
        hs.AddStretchSpacer()
        hs.Add(title, 0, wx.ALIGN_CENTER)
        hs.AddStretchSpacer()
        header.SetSizer(hs)
        sizer.Add(header, 0, wx.EXPAND)

        # all chat list
        self.chat_list = ChatList(panel)
        sizer.Add(self.chat_list, 1, wx.EXPAND)

        panel.SetSizer(sizer)
        self.Show()
    def refresh_chats(self):
        self.chat_list.refresh_list()

    def Add_Chat(self,user_name):
        self.chat_list.AddChat({"name": user_name, "last_msg": "no last msg", "time": "----",'msg':[]})

class WxVpnChatClient(wx.Frame):
    def __init__(self):
        style = wx.DEFAULT_FRAME_STYLE & ~(wx.RESIZE_BORDER | wx.MAXIMIZE_BOX)
        super().__init__(parent=None, title="VPN Chat", size=(APP_SIZE_X, APP_SIZE_Y), style=style)

        self.Bind(wx.EVT_CLOSE, self.onExitLogin)

        self.chat_page=None
        self.state = "Not Connected"
        self.client_sock = None
        self.listener = None

        self.panel = wx.Panel(self)
        self.panel.SetBackgroundColour(wx.Colour(245, 248, 255))

        self.WxVpnChatLoginPage()

        self.Centre()
        self.Show()


    def WxVpnChatLoginPage(self):
        title = wx.StaticText(self.panel, label="VPN CHAT LOGIN")
        title.SetFont(wx.Font(16, wx.FONTFAMILY_SWISS, wx.FONTSTYLE_NORMAL, wx.FONTWEIGHT_BOLD))
        title.SetPosition((40, 20))

        lbl_font = wx.Font(11, wx.FONTFAMILY_SWISS, wx.FONTSTYLE_NORMAL, wx.FONTWEIGHT_NORMAL)

        username_lbl = wx.StaticText(self.panel, label="Username:")
        username_lbl.SetFont(lbl_font)
        username_lbl.SetPosition((40, 70))

        password_lbl = wx.StaticText(self.panel, label="Password:")
        password_lbl.SetFont(lbl_font)
        password_lbl.SetPosition((40, 120))

        ip_lbl = wx.StaticText(self.panel, label="Server IP:")
        ip_lbl.SetFont(lbl_font)
        ip_lbl.SetPosition((40, 170))

        self.username = wx.TextCtrl(self.panel, size=(200, -1), pos=(140, 65))
        self.username.SetHint("Enter username")

        self.password = wx.TextCtrl(self.panel, style=wx.TE_PASSWORD, size=(200, -1), pos=(140, 115))
        self.password.SetHint("Enter password")

        self.server_ip = wx.TextCtrl(self.panel, size=(200, -1), pos=(140, 165))
        self.server_ip.SetValue("127.0.0.1")

        btn_font = wx.Font(10, wx.FONTFAMILY_SWISS, wx.FONTSTYLE_NORMAL, wx.FONTWEIGHT_BOLD)

        login_btn = wx.Button(self.panel, label="Connect", pos=(60, 230), size=(120, 35))
        login_btn.SetFont(btn_font)
        login_btn.SetBackgroundColour(wx.Colour(0, 120, 215))
        login_btn.SetForegroundColour(wx.WHITE)

        signup_btn = wx.Button(self.panel, label="Sign Up", pos=(200, 230), size=(120, 35))
        signup_btn.SetFont(btn_font)
        signup_btn.SetBackgroundColour(wx.Colour(0, 200, 100))
        signup_btn.SetForegroundColour(wx.WHITE)

        disconnect_btn = wx.Button(self.panel, label="Disconnect", pos=(120, 290), size=(120, 35))
        disconnect_btn.SetFont(btn_font)
        disconnect_btn.SetBackgroundColour(wx.Colour(0, 0, 0))
        disconnect_btn.SetForegroundColour(wx.WHITE)

        try:
            img = wx.Image("VPN_ICON.png", wx.BITMAP_TYPE_PNG).Scale(300, 250)
            img_bitmap = wx.StaticBitmap(self.panel, bitmap=wx.Bitmap(img))
            img_bitmap.SetPosition((350, 50))
        except Exception as e:
            print("Could not load image:", e)

        login_btn.Bind(wx.EVT_BUTTON, self.OnTcpConnect)
        signup_btn.Bind(wx.EVT_BUTTON, self.SignUp)
        disconnect_btn.Bind(wx.EVT_LEFT_DOWN,self.Disconnect)


    def OnTcpConnect(self, event):
        global client_sock
        global key
        global user_name
        if self.username.GetValue() == "" or self.password.GetValue() == "":
            wx.MessageBox("Please enter username and password")
            return
        print('Trying to connect...')

        try:
            if self.state == 'Signup':
                wx.MessageBox("...Signup", "Signup", wx.OK | wx.ICON_INFORMATION)
                self.client_sock = socket.socket()
                client_sock = self.client_sock
                self.client_sock.connect((self.server_ip.GetValue(), 8888))

                public_key = self.client_sock.recv(2048)
                public_key = rsa.PublicKey.load_pkcs1(public_key)
                self.key = os.urandom(16).hex()
                print(self.key)
                self.client_sock.send(rsa.encrypt(self.key.encode(), public_key))
                user_name = self.username.GetValue()
                send_with_AES(self.client_sock,
                              b'SGNU~'+(user_name).encode()+b'~'+(self.password.GetValue()).encode(),
                              self.key)
                self.listener = threading.Thread(target=self.listen)
                self.listener.start()
                key = self.key
                return

            elif self.state == 'Not Connected':
                wx.MessageBox("...connecting", "Log in", wx.OK | wx.ICON_INFORMATION)
                self.client_sock = socket.socket()
                client_sock = self.client_sock
                self.client_sock.connect((self.server_ip.GetValue(), 8888))

                public_key = self.client_sock.recv(2048)
                public_key = rsa.PublicKey.load_pkcs1(public_key)
                self.key = os.urandom(16).hex()
                print(self.key)
                self.client_sock.send(rsa.encrypt(self.key.encode(), public_key))
                user_name = self.username.GetValue()
                send_with_AES(self.client_sock,
                              b'LOGN~' + (user_name).encode() + b'~' + (self.password.GetValue()).encode(),
                              self.key)
                self.listener = threading.Thread(target=self.listen)
                self.listener.start()
                key = self.key
                return
            print("cant connect again check if you are connected!")

        except Exception as err:
            wx.MessageBox("Error while trying to connect: " + str(err))


    def ShowChatsPage(self):
        if not self.chat_page:
            self.chat_page = WxVpnChatPage()
        else:
            self.chat_page.Show()
            self.chat_page.Raise()

    def listen(self):
        self.client_sock.settimeout(0.1)
        while True:
            try:
                if self.client_sock is None:
                    break
                data = self.recv_data()
                print(data)
                if data == b"" or not data:
                    print("server went down, No Connection")
                    break
                elif data == b'EXTR':
                    print('Connection closed')
                    break
                else:
                    self.protocol_parse_reply(data)

            except socket.error as e:
                if e.errno == 10035 or str(e) == "timed out":
                    continue
            except Exception as err:
                print(str(err))

    def safe_add_chat(self,user_name):
        if any(chat["name"] == user_name for chat in chat_data):
            return
        if self.chat_page:
            self.chat_page.Add_Chat(user_name)
        else:
            self.ShowChatsPage()

    def protocol_parse_reply(self,data):
        global chat_data
        global client_sock
        global key
        print(str(datetime.datetime.now())[:19] + " ~ " + str(data.decode()))
        data = data.decode()
        MsgCode = data[:4]
        fields = ''
        if '~' in data:
            fields = data.split('~')

        if MsgCode == 'GETM':
            sender = fields[1]
            message = fields[2]
            now = str(datetime.datetime.now())[:19]

            if not any(chat['name'] == sender for chat in chat_data):
                new_chat = {"name": sender, "last_msg": message, "time": now, "msg": [message]}
                chat_data.append(new_chat)
            else:
                for chat in chat_data:
                    if chat['name'] == sender:
                        chat['msg'].append(message)
                        chat['last_msg'] = message
                        chat['time'] = now
                        break

            if self.chat_page:
                wx.CallAfter(self.chat_page.refresh_chats)

            if sender in open_chat_windows:
                wx.CallAfter(open_chat_windows[sender].append_message, f"{sender}: {message}")

        elif MsgCode == 'CONU':
            if not self.user_name == fields[1]:
                wx.CallAfter(self.safe_add_chat,fields[1])
                send_with_AES(client_sock, f'SDSM~hi there!!!~{fields[1]}~{user_name}'.encode(), self.key)

        elif MsgCode == 'ERRR':
            if fields[1] == '004':
                self.client_sock = None
                self.user_name = None
                self.key = None
                key = None
                try:
                    if self.listener and self.listener.is_alive():
                        self.listener.join(timeout=1)
                        self.listener = None
                        client_sock = None
                    print('Login has failed!')
                except Exception as err:
                    print(str(err))
            elif fields[1] == '005':
                self.client_sock = None
                client_sock = None
                self.user_name = None
                self.key = None
                key = None
                try:
                    if self.listener and self.listener.is_alive():
                        self.listener.join(timeout=1)
                        self.listener = None
                    print('Signup has failed!')
                except Exception as err:
                    print(str(err))


        elif MsgCode == 'SGNR':
            self.state = 'Connected'
            self.user_name = self.username.GetValue()
            print("state = Connected")
            wx.CallAfter(self.ShowChatsPage)

        elif MsgCode == 'LGNR':
            if fields[1] == 'OK':
                self.state = 'Connected'
                self.user_name = self.username.GetValue()
                print("state = Connected")
                wx.CallAfter(self.ShowChatsPage)
            else:
                print('Error Occurred')

    def Disconnect(self,event):
        global client_sock
        global key
        send_with_AES(client_sock,f'EXIT~{user_name}'.encode(),key)
        self.state = 'Not Connected'
        if self.chat_page:
            self.chat_page.Destroy()
        self.chat_page = None

        for win in open_chat_windows.values():
            if win and win.IsShown():
                win.Destroy()
        open_chat_windows.clear()

        if self.listener and self.listener.is_alive():
            self.listener.join(timeout=1)
            self.listener = None
            self.client_sock = None

    def onExitLogin(self, event):
        print('BYE')
        self.state = 'Not Connected'
        if self.chat_page:
            self.chat_page.Destroy()
        self.chat_page = None
        for win in open_chat_windows.values():
            if win and win.IsShown():
                win.Destroy()
        open_chat_windows.clear()
        if self.listener and self.listener.is_alive():
            self.listener.join(timeout=1)
            self.listener = None
            self.client_sock = None
        self.Destroy()

    def update_users(self,arr):
        for user in arr:
            wx.CallAfter(self.safe_add_chat,user)

    def SignUp(self, event):
        self.state = "Signup"
        wx.MessageBox("Write your user name and password then press login!", "Signup", wx.OK | wx.ICON_INFORMATION)

    def recv_data(self):
        data = recv_with_AES(self.client_sock, self.key)
        return data

    def send_data(self, bdata):
        send_with_AES(self.client_sock, bdata, self.key)

def main():
    app = wx.App(False)
    WxVpnChatClient()
    app.MainLoop()

if __name__ == '__main__':
    main()


