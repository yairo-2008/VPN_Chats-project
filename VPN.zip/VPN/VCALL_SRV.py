# server_video.py
import cv2, socket, threading, time, numpy as np
from aes_functions import recv_with_AES, send_with_AES

all_to_die = False

def video_receiver(port, session_key):
    global all_to_die
    srv_sock = socket.socket()
    srv_sock.bind(('0.0.0.0', port))
    srv_sock.listen(1)
    print('Waiting for client...')
    client_sock, addr = srv_sock.accept()
    print(f'Connected:{addr}')

    while not all_to_die:
        try:
            data = recv_with_AES(client_sock, session_key)
            frame = cv2.imdecode(np.frombuffer(data, np.uint8), cv2.IMREAD_COLOR)
            if frame is None:
                continue
            cv2.imshow('Incoming', frame)
            if cv2.waitKey(1) == 27:      # ESC
                all_to_die = True
        except Exception as e:
            print('Error Occoured:', e)
            all_to_die = True

    client_sock.close()
    cv2.destroyAllWindows()

def video_sender(port, session_key):
    global all_to_die
    srv_sock = socket.socket()
    srv_sock.bind(('0.0.0.0', port + 10))
    srv_sock.listen(1)
    print('Waiting for client...')
    client_sock, addr = srv_sock.accept()
    print(f'Connected:{addr}')

    cap = cv2.VideoCapture(0)
    while not all_to_die:
        ret, frame = cap.read()
        if not ret:
            continue
        _, buffer = cv2.imencode('.jpg', frame, [cv2.IMWRITE_JPEG_QUALITY, 80]) #שמירה זמנית בזכרון
        try:
            send_with_AES(client_sock, buffer.tobytes(), session_key)
        except Exception as e:
            print('Error:', e)
            all_to_die = True
        time.sleep(0.04)

    cap.release()
    client_sock.close()

def video_call_server(port, key):
    threads = [
        threading.Thread(target=video_sender,   args=(port, key)),
        threading.Thread(target=video_receiver, args=(port, key))
    ]
    for t in threads: t.start()
    for t in threads: t.join()

if __name__ == '__main__':
    video_call_server(2223, b'omer')