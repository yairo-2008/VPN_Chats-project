__author__ = 'Omer'


from aes_functions import recv_with_AES,send_with_AES
from AsyncMessages import AsyncMessages
import threading, traceback, time,socket,hashlib,secrets,string,pickle,os,pathlib,rsa


USERS_NAME_PASS = {}
USERS_ASYNC_MSG = AsyncMessages()
CONNECTED_USERS = []

all_to_die = False
IP = '192.0.0.'

PUBLIC_KEY = "public key"
PRIVATE_KEY = "private key"


def generate_new_rsa_keys():
    """
    to generate new rsa keys
    :return: files of pem with the keys
    """
    global PRIVATE_KEY
    global PUBLIC_KEY

    PUBLIC_KEY,PRIVATE_KEY = rsa.newkeys(1024)
    with open("public_key.pem","wb") as f:
        f.write(PUBLIC_KEY.save_pkcs1("PEM"))
    with open("private_key.pem","wb") as f:
        f.write(PRIVATE_KEY.save_pkcs1("PEM"))

def get_existing_rsa_keys():
    """
    to get existing rsa keys from the pem files
    :return: PUBLIC_KEY and PRIVATE_KEY parm
    """
    global PUBLIC_KEY
    global PRIVATE_KEY

    with open("public_key.pem","rb") as f:
        PUBLIC_KEY = rsa.PublicKey.load_pkcs1(f.read())
    with open("private_key.pem","rb") as f:
        PRIVATE_KEY = rsa.PrivateKey.load_pkcs1(f.read())

def logtcp(direction, tid, byte_data):
    """
    log direction, tid and all TCP byte array data
	return: void
	"""
    if direction == 'sent':
        print(f'{tid} S LOG:Sent     >>> {byte_data}')
    else:
        print(f'{tid} S LOG:Received <<< {byte_data}')

def GetUpdatedListUsers():
    global Connected_Users
    all_users = 'UPDATED LIST OF USERS: '
    for k,v in Connected_Users.items():
        all_users += str(v) + ','
    return all_users

def IsAccountExistWithThisName(user_name):
    global USERS_NAME_PASS
    for k,v in USERS_NAME_PASS.items():
        if k == user_name:
            return True
    return False

def login(user_name,user_pass):
    global USERS_NAME_PASS
    global USERS_ASYNC_MSG
    global CONNECTED_USERS

    users_tuple = USERS_NAME_PASS.get(user_name)
    if users_tuple is None:
        return 'ERRR~004~Login failed!!! there is no account exist like this'
    salt = users_tuple[2]
    if (hashlib.sha256((user_pass + salt).encode()).hexdigest() == users_tuple[1] and
        hashlib.sha256((user_name + salt).encode()).hexdigest() == users_tuple[0]):

        if user_name not in CONNECTED_USERS:
            CONNECTED_USERS.append(user_name)

        USERS_ASYNC_MSG.put_msg_to_all(f'CONU~{user_name}')
        return f'LGNR~OK'
    else:
        return 'ERRR~004~Login failed!!! change password or the users name'

def SignUp(data):
    """
    if signup succeed return true
    :param data:
    :return:
    """
    global USERS_NAME_PASS
    global USERS_ASYNC_MSG
    global CONNECTED_USERS

    user_name = data[1]
    if not IsAccountExistWithThisName(user_name):
        all_chars = string.printable.strip()
        length = 16
        random_salt = ''.join(secrets.choice(all_chars) for _ in range(length))
        USERS_NAME_PASS[user_name] = (hashlib.sha256((user_name + random_salt).encode()).hexdigest(),
                                      hashlib.sha256((data[2] + random_salt).encode()).hexdigest(),
                                      random_salt)
        with open("users.pkl", "wb") as file:
            pickle.dump(USERS_NAME_PASS, file)

        if user_name not in CONNECTED_USERS:
            CONNECTED_USERS.append(user_name)

        USERS_ASYNC_MSG.add_new_user(user_name)
        USERS_ASYNC_MSG.put_msg_to_all(f'CONU~{user_name}')
        return True
    return False


def send_data(sock,tid,bdata,key):
    """
	send to client byte array data
	will add 8 bytes message length as first field
	e.g. from 'abcd' will send  b'00000004~abcd
	return: void
	"""
    send_with_AES(sock,bdata,key)
    logtcp('sent',tid, bdata)
    print("")


def check_length(message):
    """
    check message length
	return: string - error message
	"""
    if message:
        size = len(message)
        if size < 0:  # 12 is min message size
            return b'ERRR~003~Bad Format message too short'
    return b''

def delete_user(user_name,sock):
    global Connected_Users
    if user_name is not None and sock is not None:
        USERS_ASYNC_MSG.delete_user(user_name)
        msg = 'User Logged Out--> ' + user_name
        USERS_ASYNC_MSG.put_msg_to_all(
            f'server~Message content:  {msg} ---it was sent to all users---')

def protocol_build_reply(request,sock):
    """
    Application Business Logic
    function despatcher ! for each code will get to some function that handle specific request
    Handle client request and prepare the reply info
    string:return: reply
    """
    global USERS_NAME_PASS
    global USERS_ASYNC_MSG
    global CONNECTED_USERS

    request = request.decode("utf8")
    request_code = request[:4]
    if '~' in request:
        request = request.split('~')
    if request_code == 'EXIT':
        delete_user(request[1],sock)
        reply = 'EXTR'
        print('got exit request from client')
        return reply.encode(),True

    elif request_code == 'SDSM':
        USERS_ASYNC_MSG.put_msg_by_user(f'GETM~{request[3]}~Message content:   {request[1]} \n---it was sent to you private---', request[2])
        reply = f'GETM~server~message sent to {request[2]}'


    elif request_code == 'SALL':
        USERS_ASYNC_MSG.put_msg_to_all(
            f'{request[1]}~Message content:  {request[2]} ---it was sent to all users---')
        reply = 'GETM~server~message sent to everyone! by you'

    else:
        reply = 'ERRR~002~code not supported'
        return reply.encode(), True

    return reply.encode(),False

def handle_request(request,sock):
    """
    handle client request
    tuple :return: return message to send to client and bool if to close the client socket
    """
    try:
        to_send,finish = protocol_build_reply(request,sock)
    except Exception as err:
        print(traceback.format_exc()+str(err))
        to_send = b'ERRR~001~General error'
        finish = True
    return to_send, finish


def CheckAndSendStringMessages(sock,user_name,tid,key):
    global USERS_NAME_PASS
    for msg in USERS_ASYNC_MSG.get_async_messages_to_send(user_name):
        if msg is None:
            continue
        else:
            send_data(sock, tid, msg.encode(), key)

def handle_client(sock, tid , addr):
    """
	Main client thread loop (in the server),
	:param sock: client socket
	:param tid: thread number
	:param addr: client ip + reply port
	:return: void
	"""
    global USERS_ASYNC_MSG
    global all_to_die
    global USERS_NAME_PASS
    global PUBLIC_KEY
    global PRIVATE_KEY
    global CONNECTED_USERS

    finish = False
    print(f'New Client number {tid} from {addr}')
    user_name = "user"

    PEM_PATH = pathlib.Path("public_key.pem")
    pub_bytes = PEM_PATH.read_bytes()
    sock.send(pub_bytes)
    encrypted_session_key = sock.recv(1024)
    session_key = rsa.decrypt(encrypted_session_key, PRIVATE_KEY).decode()
    print(session_key)
    connect = False
    user_name = 'user'
    while not connect:

        byte_data = recv_with_AES(sock, session_key)
        request = byte_data.decode("utf8")
        request_code = request[:4]
        request = request.split('~')
        if request_code == 'SGNU':
            if SignUp(request):
                send_data(sock,tid,b'SGNR',session_key)
                user_name = request[1]
                break
            else:
                send_data(sock,tid,b'ERRR~005~SignUp failed!!! there is an account exist with this name!! change it',session_key)

        elif request_code == 'LOGN':
            send_data(sock,tid,login(request[1], request[2]).encode(),session_key)
            user_name = request[1]
            break
    print(f'handle:{tid}')

    sock.settimeout(0.1)
    while not finish:
        if all_to_die:
            print('will close due to main server issue')
            break
        try:
            byte_data = recv_with_AES(sock,session_key)  # todo improve it to recv by message size
            if byte_data == b'' or byte_data is None:
                print('Seems client disconnected')
                break
            logtcp('recv', tid, byte_data)
            err_size = check_length(byte_data)
            if err_size != b'':
                to_send = err_size
            else:
                to_send, finish = handle_request(byte_data,sock)
            if to_send != '':
                print(f'before encrypt:{to_send}')
                send_data(sock, tid, to_send,session_key)
            if finish:
                time.sleep(1)
                break

        except socket.timeout and TimeoutError:
            CheckAndSendStringMessages(sock,user_name, tid,session_key)

        except socket.error as err:
            print(f'Socket Error exit client loop: err:  {err}')
            break

        except Exception as err:
            print(f'General Error %s exit client loop: {err}')
            print(traceback.format_exc())
            break
    print(f'Client {tid} Exit')
    print('bye')
    sock.close()


def main():
    """
    main server loop
    1. accept tcp connection
    2. create thread for each connected new client
    3. wait for all threads
    4. every X clients limit will exit
    """
    global all_to_die
    global USERS_NAME_PASS
    global USERS_ASYNC_MSG
    global IP
    threads = []

    srv_sock = socket.socket()
    srv_sock.bind(('0.0.0.0', 8888))
    srv_sock.listen(0)

    # next line release the port
    srv_sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)

    if os.path.exists('users.pkl') and os.path.getsize('users.pkl') > 0:
        with open('users.pkl', "rb") as file:
            USERS_NAME_PASS = pickle.load(file)

    print(USERS_NAME_PASS)

    get_existing_rsa_keys()

    i = 1
    print('server is up!\nMain thread: before accepting ...')
    while True:
        cli_sock, addr = srv_sock.accept()
        ip = IP+str(i)
        t = threading.Thread(target=handle_client, args=(cli_sock, ip, addr))
        t.start()
        i += 1
        threads.append(t)
        if i > 100:  # for tests change it to 4
            print('\nMain thread: going down for maintenance')
            break

    all_to_die = True
    print('Main thread: waiting to all clients to die')
    for t in threads:
        t.join()
    srv_sock.close()
    print('Bye ..')


if __name__ == '__main__':
    main()