
import threading
from logging import exception


class AsyncMessages():
    """
        this class provide global messages area for server that handle muktyclients by threads
        its enable many threads to communicate by one dictionary (self.async_msgs)
        each thread might put data to specific other thread (the key is the other thread socket)
        each thread can get his messages by his socket
        this class is thread safe
    """

    def __init__(self):
        self.lock_async_msgs = threading.Lock()
        self.async_msgs = {}

    def add_new_user(self, new_client):
        """
            call to this method right after socket accept with client socket
        """
        self.async_msgs [new_client] = []


    def delete_user(self, user):
        """
            when disconnect
        """
        del self.async_msgs [user]


    def put_msg_by_user(self,data, user):
        try:
            self.lock_async_msgs.acquire()
            self.async_msgs[user].append(data)
            self.lock_async_msgs .release()
        except KeyError:
            return
        
    def put_msg_to_all(self,data):
        self.lock_async_msgs.acquire()
        for s in self.async_msgs.keys():
            self.async_msgs[s].append(data)
        self.lock_async_msgs .release()
        
    

    def get_async_messages_to_send(self, my_user):
        try:
            msgs = []
            if not self.async_msgs.get(my_user):
                return msgs
            elif self.async_msgs.get(my_user) != []:
                self.lock_async_msgs .acquire()
                msgs =  self.async_msgs[my_user]
                self.async_msgs[my_user] =[]
                self.lock_async_msgs .release()
            return msgs
        except KeyError:
            return

